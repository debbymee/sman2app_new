	        <div class="x_panel">
			<div class="container">

		 	<h2 style="color: green " align="center"> LAPORAN PRESENSI SISWA KELAS 10 IPS 1</h2> 
		    <hr>
		     <br><br>
		           
                 

		
		


	
		<table id="datatable" class="table table-striped table-bordered">
			<thead>
			<tr align="center">
				<td>NO</td>
				<td>NIPD</td>
				<td>NAMA SISWA</td>
				<td>JK</td>
			
				
				<td>CETAK</td>
			</tr>
			</thead>

			<tbody>

			<?php 
				$no = 1;
				foreach ($siswa as $sw){
			 ?>
			 <tr>
			 	
				<td><?php echo $no++ ?></td>
				<td><?php echo $sw->nipd ?></td>
			 	<td><?php echo $sw->nama_siswa ?></td>
			 	<td><?php echo $sw->jk ?></td>
			 	<td><a class="btn btn-success" href="<?php echo site_url('wali_kelas/detail_cetak_siswa/'.$sw->id_siswa); ?>">Cetak</td>
			 	
			 </tr>

			<?php } ?>
			</tbody>
		</table>