
    <div class="x_panel">
    <div class="container">
      <center><h2 style="color: green "> DETAIL DATA SISWA</h2></center> <hr>
      <br> 

   <form action="<?php echo base_url(); ?>wali_kelas/lihat_laporan_persiswa" method ="post"  class="form-horizontal form-label-left"  >
  


              <div class="item form-group">
                  <label class="control-label col-md-4 col-sm-3 col-xs-12" for="nama_siswa">NAMA SISWA <span class="required">*</span>
                  </label>
                  
                  <div class="col-md-3 col-sm-6 col-xs-12">

                    <input id="nama_siswa" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="nama_siswa" placeholder="masukkan nama siswa" readonly type="text" value="<?php echo $siswa->nama_siswa ?>">
                  
                    <?php echo form_error('nama_siswa', '<small class="text-danger pl-3">', '</small>'); ?> <br> 

                  </div>

                </div>

                <div class="item form-group">

                    <label class="control-label col-md-4 col-sm-3 col-xs-12" for="nipd">NIPD<span class="required">*</span>
                    </label>

                    <div class="col-md-3 col-sm-6 col-xs-12">

                      <input id="nipd" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="nipd" placeholder="masukkan nipd siswa"  type="text" readonly value="<?php echo $siswa->nipd ?>">
                     
                    <?php echo form_error('nipd', '<small class="text-danger pl-3">', '</small>'); ?> <br> 

                    </div>

              </div>


           

                <div class="item form-group">
                  <label class="control-label col-md-4 col-sm-3 col-xs-12" for="jk">Pilih Tanggal Cetak <span class="required">*</span>
                  </label>

                  <div class="col-md-3 col-sm-6 col-xs-12">

                    
                     <input type="text" name="datefilter" autocomplete="off" value="" placeholder="Choose Date Report"/> <br>  
                                    
                  </div>

              </div>


               <input type="hidden" id="dateawal" value="" name="tgl_awal" placeholder="Date awal"/>
               <input type="hidden" id="dateakhir" value="" name="tgl_akhir" placeholder="Date awal"/>
         
         
         <input type="hidden" value="<?php echo $siswa->id_kelas ?>" name="id_kelas"/>


          <input type="hidden" value="<?php echo $siswa->id_siswa ?>" name="id_siswa"/>


             
   

      <div class="ln_solid"></div>
          <div class="form-group">
            <div class="col-md-3 col-md-offset-4">
            <button type="submit" class="btn btn-success">Submit</button>
              <button type="reset" class="btn btn-primary">Cancel</button>

            </div>
          </div>

 
</form>
          <?php //echo form_close(); ?>
     

  </div>
</div>
