        <div class="x_panel">
            <div class="container">

            <h2 style="color: green " align="center"> LAPORAN PRESENSI SISWA PERBULAN </h2>
            <hr>
             <br><br>
                   
                 

        
         <form action="<?php echo base_url(); ?>wali_kelas/cetak_bulan" method ="post"  class="form-horizontal form-label-left" enctype="multipart/form-data" >


  <div class="form-group">
                <div class="col-md-8 ">
                <label>Masukkan bulan</label>
                </div>

                <div class="col-md-6 col-sm-6 col-xs-12">

                       
                         <?php if ($this->session->userdata('semester')=='Genap') { ?>
 
                            <select class="btn btn-default dropdown-toggle" name="bulan">
                         
                            <option value="01">Januari</option>
                            <option value="02">Februari</option>
                            <option value="03">Maret</option>
                            <option value="04">April</option>
                            <option value="05">Mei</option>
                            <option value="06">Juni</option>
                            
                       
                          </select>
                          <?php } ?>
                          
                        </div>
            </div>

          
                    
                

        
               <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-12">
                        <button id="send" type="submit" class="btn btn-success" target="_blank"><i class="fa fa-print"> </i> Cetak</button>
                          
                        </div>
                      </div>

</form>

</div>
</div>
</div>
</div>
</div>